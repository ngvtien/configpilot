import React from "react"
import FormBasedValueEditor from "./FormBasedValueEditor"

function App() {
  return (
    <div className="app">
      <FormBasedValueEditor />
    </div>
  )
}

export default App
