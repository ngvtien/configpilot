"use client"
import AppLayout from "./components/AppLayout"

const App = () => {
  return <AppLayout />
}

export default App

// import React from 'react';
// import ChartFileTest from './components/ChartFileTest';

// function App() {
//   return (
//     <div className="App">
//       <ChartFileTest />
//     </div>
//   );
// }

// export default App;